package dgsw.hs.kr.myapplication;

import android.provider.BaseColumns;

public class DataBases {
    public static final class CreateDB implements BaseColumns{
        public static final String AL_CUP = "cup";
        public static final String AL_BOTTLE = "bottle";
        public static final String AL_DATE = "date";

        public static final String TO_ONE = "one";
        public static final String TO_PACK = "pack";
        public static final String TO_DATE = "date";

        public static final String TABLE_AL = "Alcohol";
        public static final String TABLE_TO = "Tobacco";
        public static final String CREATE_AL = "create table " + TABLE_AL + "("
                                                    +AL_CUP + " integer,"
                                                    +AL_BOTTLE + " integer,"
                                                    +AL_DATE + " integer" +
                                                ");";
        public static final String CREATE_TO = "create table " + TABLE_TO + "("
                                                    +TO_ONE + " integer,"
                                                    +TO_PACK + " integer,"
                                                    +TO_DATE + " integer" +
                                                ");";

    }
}
