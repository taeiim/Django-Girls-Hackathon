package dgsw.hs.kr.myapplication;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.File;
import java.util.Calendar;

public class MainFragment extends Fragment {
    SQLiteDatabase sqliteDB;
    DBOpenHelper helper;
    View view;
    EditText alcoholDate;
    EditText tobaccoDate;
    Calendar calendar = Calendar.getInstance();

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_main, container, false);

        helper = new DBOpenHelper(getActivity());
        helper.open();

        RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.RadioGroup);
        final TextView alcoholCup = (TextView) view.findViewById(R.id.alcoholCup);
        final TextView alcoholBottle = (TextView) view.findViewById(R.id.alcoholBottle);
        final TextView tobaccoOne = (TextView) view.findViewById(R.id.tobaccoOne);
        final TextView tobaccoPack = (TextView) view.findViewById(R.id.tobaccoPack);
        final Button alcoholSave = (Button) view.findViewById(R.id.alcoholSave);
        final Button tobaccoSave = (Button) view.findViewById(R.id.tobaccoSave);
        alcoholDate = view.findViewById(R.id.alcoholDate);
        tobaccoDate = view.findViewById(R.id.tobaccoDate);


        alcoholSave.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.insertAl(Integer.parseInt(alcoholCup.getText().toString()), Integer.parseInt(alcoholBottle.getText().toString()), alcoholDate.getText().toString());
            }
        });

        tobaccoSave.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.insertTo(Integer.parseInt(tobaccoOne.getText().toString()), Integer.parseInt(tobaccoPack.getText().toString()), tobaccoDate.getText().toString());
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RelativeLayout alcoholDatePicker = (RelativeLayout) view.findViewById(R.id.alcoholDatePicker);
                RelativeLayout tobaccoDatePicker = (RelativeLayout) view.findViewById(R.id.tobaccoDatePicker);

                if (checkedId == R.id.alcohol) {
                    tobaccoOne.setVisibility(View.GONE);
                    tobaccoPack.setVisibility(View.GONE);
                    alcoholCup.setVisibility(View.VISIBLE);
                    alcoholBottle.setVisibility(View.VISIBLE);
                    alcoholSave.setVisibility(View.VISIBLE);
                    tobaccoSave.setVisibility(View.GONE);
                    alcoholDatePicker.setVisibility(View.VISIBLE);
                    tobaccoDatePicker.setVisibility(View.GONE);
                    alcoholDate.setInputType(0);
                    alcoholDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            new DatePickerDialog(getActivity(), alcoholDateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
                        }
                    });
                } else if (checkedId == R.id.tobacco) {
                    alcoholCup.setVisibility(View.GONE);
                    alcoholBottle.setVisibility(View.GONE);
                    tobaccoOne.setVisibility(View.VISIBLE);
                    tobaccoPack.setVisibility(View.VISIBLE);
                    alcoholSave.setVisibility(View.GONE);
                    tobaccoSave.setVisibility(View.VISIBLE);
                    alcoholDatePicker.setVisibility(View.GONE);
                    tobaccoDatePicker.setVisibility(View.VISIBLE);
                    tobaccoDate.setInputType(0);
                    tobaccoDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            new DatePickerDialog(getActivity(), tobaccoDateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
                        }
                    });
                }
            }
        });
        return view;
    }

    private DatePickerDialog.OnDateSetListener alcoholDateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
            String msg = String.format("%d / %d / %d", year, monthOfYear + 1, dayOfMonth);
            alcoholDate.setText(msg);
        }
    };

    private DatePickerDialog.OnDateSetListener tobaccoDateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
            String msg = String.format("%d / %d / %d", year, monthOfYear + 1, dayOfMonth);
            tobaccoDate.setText(msg);
        }
    };
}
