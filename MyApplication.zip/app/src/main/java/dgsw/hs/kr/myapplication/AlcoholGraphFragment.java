package dgsw.hs.kr.myapplication;

import android.app.DatePickerDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AlcoholGraphFragment extends Fragment implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {
    private Context mContext;
    private List<Button> buttonList = null;
    private EditText startDateEditText;
    private EditText finishDateEditText;
    private int sYear, sMonth, sDay;
    private int fYear, fMonth, fDay;
    static final int DATE_ID = 0;
    SQLiteDatabase database;
    DBOpenHelper helper;
    Calendar calendar = Calendar.getInstance();
    View view;

    public Cursor getAlcohol(String date){
        Cursor c = helper.getAl(date);
        return c;
    }

    public Cursor getTobacco(String date){
        Cursor c = helper.getTo(date);
        return c;
    }

    public static AlcoholGraphFragment newInstance() {
        return new AlcoholGraphFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_alcohol_graph, container, false);

        RelativeLayout datePickerView = view.findViewById(R.id.datePickerView);
        startDateEditText = view.findViewById(R.id.startdateEditText);
        finishDateEditText = view.findViewById(R.id.finishdateEditText);
        datePickerView.setVisibility(View.GONE);

        LineChartSet();
        BarChartSet();
        ChartView();

        mContext = getActivity();
        initSegmentbuttons();

        startDateEditText.setInputType(0);
        startDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(getActivity(), dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        finishDateEditText.setInputType(0);
        finishDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(getActivity(), dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        helper = new DBOpenHelper(getActivity());
        helper.open();

        return view;
    }

    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
            String msg = String.format("%d / %d / %d", year, monthOfYear + 1, dayOfMonth);
            startDateEditText.setText(msg);

        }
    };

    private void ChartView() {
        final LineChart lineChart = view.findViewById(R.id.chart_alcohol);
        final BarChart barChart = view.findViewById(R.id.chart_alcohol_Bar);

        Button lineBtn = view.findViewById(R.id.lineBtn);
        Button barBtn = view.findViewById(R.id.barBtn);

        lineBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                barChart.setVisibility(View.GONE);
                lineChart.setVisibility(View.VISIBLE);
                lineChart.animateY(1000);
            }
        });

        barBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lineChart.setVisibility(View.GONE);
                barChart.setVisibility(View.VISIBLE);
                barChart.animateY(1000);
            }
        });
    }

    private void LineChartSet() {
        LineChart lineChart = view.findViewById(R.id.chart_alcohol);

        ArrayList<String> labels = new ArrayList<String>();
        labels.add("Jan");
        labels.add("Feb");
        labels.add("mar");
        labels.add("fafe");

        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(0, 0f));
        entries.add(new Entry(1, 2f));
        entries.add(new Entry(2, 9f));
        entries.add(new Entry(3, 4f));

        LineDataSet dataSet = new LineDataSet(entries, "# of Calls");
        LineData data = new LineData(dataSet);
        lineChart.setData(data);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawAxisLine(true);
        xAxis.setDrawGridLines(true);
        lineChart.getAxisRight().setDrawLabels(false);

        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        lineChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));

        lineChart.setVisibility(View.GONE);
    }

    private void BarChartSet() {
        BarChart barChart = view.findViewById(R.id.chart_alcohol_Bar);

        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0, 0f));
        entries.add(new BarEntry(1, 2f));
        entries.add(new BarEntry(2, 3f));
        entries.add(new BarEntry(3, 4f));

        BarDataSet barDataSet = new BarDataSet(entries, "Dates");

        ArrayList<String> labels = new ArrayList<>();
        labels.add("Jan");
        labels.add("Feb");
        labels.add("mar");
        labels.add("fafe");

        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawAxisLine(true);
        xAxis.setDrawGridLines(true);
        barChart.getAxisRight().setDrawLabels(false);

        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        barChart.animateY(1000);
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
    }

    private void initSegmentbuttons() {
        buttonList = new ArrayList<>();

        Button btnWeek = view.findViewById(R.id.buttonWeek);
        Button btn1Month = view.findViewById(R.id.button1Month);
        Button btn3Month = view.findViewById(R.id.button3Month);
        Button btn6Month = view.findViewById(R.id.button6Month);
        Button btnSelect = view.findViewById(R.id.buttonSelect);

        btnWeek.setOnClickListener(this);
        btn1Month.setOnClickListener(this);
        btn3Month.setOnClickListener(this);
        btn6Month.setOnClickListener(this);
        btnSelect.setOnClickListener(this);

        buttonList.add(btnWeek);
        buttonList.add(btn1Month);
        buttonList.add(btn3Month);
        buttonList.add(btn6Month);
        buttonList.add(btnSelect);
    }

    public void onClick(View v) {
        RelativeLayout datePickerView = view.findViewById(R.id.datePickerView);

        switch (v.getId()) {
            case R.id.buttonWeek:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button1Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button3Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button6Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.buttonSelect:
                datePickerView.setVisibility(View.VISIBLE);
                break;
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
        RelativeLayout datePickerView = view.findViewById(R.id.datePickerView);

        switch (i) {
            case R.id.buttonWeek:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button1Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button3Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.button6Month:
                datePickerView.setVisibility(View.GONE);
                break;
            case R.id.buttonSelect:
                datePickerView.setVisibility(View.VISIBLE);
                break;
        }
    }
}
