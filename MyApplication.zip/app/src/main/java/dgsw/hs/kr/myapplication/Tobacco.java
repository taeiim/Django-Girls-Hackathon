package dgsw.hs.kr.myapplication;

public class Tobacco {
    private int one;
    private int pack;
    private String date;

    public Tobacco() {
        super();
    }

    public Tobacco(int one, int pack, String date) {
        this.one = one;
        this.pack = pack;
        this.date = date;
    }

    public int getOne() {
        return one;
    }

    public int getPack() {
        return pack;
    }

    public String getDate() {
        return date;
    }

    public void setOne(int one) {
        this.one = one;
    }

    public void setPack(int pack) {
        this.pack = pack;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
