package dgsw.hs.kr.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper {
    private static final String DATABASE_NAME = "atm.db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase mDB;
    private DataBaseHelper mDBHelper;
    private Context mCtx;

    private class DataBaseHelper extends SQLiteOpenHelper {
        public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(DataBases.CreateDB.CREATE_AL);
            sqLiteDatabase.execSQL(DataBases.CreateDB.CREATE_TO);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DataBases.CreateDB.TABLE_AL);
            onCreate(sqLiteDatabase);
        }
    }

    public DBOpenHelper(Context context) {
        this.mCtx = context;
    }

    public DBOpenHelper open() throws SQLException {
        mDBHelper = new DataBaseHelper(mCtx, DATABASE_NAME, null, DATABASE_VERSION);
        mDB = mDBHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        mDB.close();
    }

    public long insertAl(int cup, int bottle, String date) {
        ContentValues values = new ContentValues();
        values.put(DataBases.CreateDB.AL_CUP, cup);
        values.put(DataBases.CreateDB.AL_BOTTLE, bottle);
        values.put(DataBases.CreateDB.AL_DATE, date);
        return mDB.insert(DataBases.CreateDB.TABLE_AL, null, values);
    }

    public long insertTo(int one, int pack, String date) {
        ContentValues values = new ContentValues();
        values.put(DataBases.CreateDB.TO_ONE, one);
        values.put(DataBases.CreateDB.TO_PACK, pack);
        values.put(DataBases.CreateDB.TO_DATE, date);
        return mDB.insert(DataBases.CreateDB.TABLE_TO, null, values);
    }

    public Cursor getAllAl() {
        return mDB.query(DataBases.CreateDB.TABLE_AL, null, null, null, null, null, null);
    }

    public Cursor getAl(String date) {
        Cursor c = mDB.query(DataBases.CreateDB.TABLE_AL, null, "date=" + date, null, null, null, null);
        if (c != null && c.getCount() != 0)
            c.moveToFirst();
        return c;
    }

    public Cursor getAllTo() {
        return mDB.query(DataBases.CreateDB.TABLE_TO, null, null, null, null, null, null);
    }

    public Cursor getTo(String date) {
        Cursor c = mDB.query(DataBases.CreateDB.TABLE_TO, null, "date=" + date, null, null, null, null);
        if (c != null && c.getCount() != 0)
            c.moveToFirst();
        return c;
    }
}
