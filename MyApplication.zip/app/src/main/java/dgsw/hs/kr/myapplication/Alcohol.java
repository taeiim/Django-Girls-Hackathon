package dgsw.hs.kr.myapplication;

public class Alcohol {
    public int cup;
    public int bottle;
    public String date;

    public Alcohol() {
        super();
    }

    public Alcohol(int cup, int bottle, String date) {
        this.cup = cup;
        this.bottle = bottle;
        this.date = date;
    }

    public int getCup() {
        return cup;
    }

    public int getBottle() {
        return bottle;
    }

    public String getDate() {
        return date;
    }

    public void setCup(int cup) {
        this.cup = cup;
    }

    public void setBottle(int bottle) {
        this.bottle = bottle;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
